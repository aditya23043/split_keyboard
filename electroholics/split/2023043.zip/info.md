
# STUFF I NEED
- M2 Screws used in between key switches
- PCB
- SWITCH MOUNT
- BOTTOM CASE

